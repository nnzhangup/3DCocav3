"""Optimizer package marker."""

